> Use this worksheet to plan the next phase of your project **before you begin coding**
> Be clear, specific, and intentional—this will guide your development this week.

---
## 📌 Project Overview

**Project Name:First Fantasy: The Dark Continent**
→   
  
**What does your program currently do? (1–3 sentences)**   
→ The intial combat encounter works, unpolished, but it functions. My two party characters initialize and display their attributes. The exploration system allows the user to 
move between all of the 7 current locations. These will be expanded greatly this week. 

---
## 🔍 Current Progress Check  
  
**What is working right now?**   
→   Combat, Exploration, Character Initialization, all of the menu options also work with the exception of load game as i have not built that into the system yet.
  
**What is NOT working or incomplete?**   
→   Random Enemy Encounters and the full story system added into the game. However, due to all of the framework I've built, this should essentially be "plug and play" to 
get the random encounters and story built into the game. 
  
**What feels confusing or messy in your code?**   
→ At the moment, some of my visual outputs aren't up to the levels of perfection I strive for. However, I wanted framework built on first, so that I could expand on this during
my final couple of weeks doing polish. 

---
## 🚀 Feature Planning  
  
List the features you plan to add or improve this week.  
  
### Feature 1  
**Name: Random enemy encounters.**   
→   
  
**What does this feature do?**   
→ This feature will take the encounter tables that I have already built and assigned to the LocationCatalog for each location. There will be a chance configured depending on the 
screen that will dictate how often an enemy encounter may take place when the player swaps between locations. 
  
**Why is this feature important?**   
→  Without this, the only way I could manage combat would be scripted encounters for the type of game I am building. While I will have a couple of scripted encounters, it is 
not something I wanted to rely fully on. 
  
---
### Feature 2  
**Name: Location Expansion**   
→   
  
**What does this feature do?**   
→   I will be polishing and expanding on the location catalog to allow for more playability. Also, with the basic 7 locations I have now, the game could be completed in a couple
of minutes, and that is not what I'm aiming for. Plus, it would make the random encounters annoying and very low %. 
  
**Why is this feature important?**   
→   in large part it will support the random encounters. For example the first location the characters start in is currently called "the road to the village". It does have a fork in the road
but with just a few choices, the player would end up at the end game dungeon. 
  
---
  
### Feature 3 (optional)  
**Name: Story Implementation**   
→   
  
**What does this feature do?**   
→   I've been writing the story in my free time the past two weeks. I've fleshed it out pretty significantly, but I was waiting on adding much of that until I had more framework built 
around it. This week I will have the story completely fleshed out and placed into the game.
  
**Why is this feature important?**   
→   
  
---
## 🧩 System Design Updates  
  
**Will you need to create any new classes? If so, which ones?**   
→   At the moment, I dont think I will require any new classes. I worked pretty extensively to plan and create the ones I would need in week one, but did find a few that I would 
need to add at the beginning of week 2. I may run into an instance of adding another depending on what comes up during coding this week, but that is yet to be seen. 
  
**Will you modify any existing classes? How?**   
→   Absolutely. Already modified quite a few this week and added a v.02 tag to those that were modified to notate changes that were made this week. 
  
**What data structures will you use (vectors, 2D vectors, etc.)?**   
→   I jumped heavily into vectors this week. I had to use quite a few of them around the locations. 
  
---
## 🔄 Program Flow  
  
**Describe how a user interacts with your program:**  
  
1. Program starts →   Upon Program Start, currently the user is shown the main menu with the following options. New Game, Load Game, How to Play, Lore, Credits, and Exit.
2. User chooses →   New Game will initiate a new game for the player to start. Load Game does not currently work. How to Play displays an option screen teaching the player
how to play. Lore has menu option for The World, Characters, Locations, Bestiary, and Return to Main Menu. Credits display the games credits. Exit game exits game. 
3. Program responds →   See below...I am including this in the Loop Next/Step as I think I will have this answered in a mix of both question 2 and 4. 
4. Loop/next step →   Upon starting the game, an opening story will display. It will then take the user into the opening combat scenario. Upon completing the combat, the user
will begin their quest to their next first location. Each option they take may have some dialog and/or story until they reach the village they are trying to reach. There 
will be locations within that village then it will engage the next big story loop.
  
---
## 🎯 Usability Improvements  
  
How will you make your program easier to use this week?  
  
- Clearer prompts:   
→   The story and location description prompts will be made clear so that the user can understand their next steps. 
  
- Better error handling:   
→   I am being intentional with my input validation as this is a text based JRPG. I will be making sure that error handling is covered by my input validation so if the user 
inputs an incorrect option they are immediately alerted. 
  
- Improved menu/navigation:   
→   Created a dynamic travel menu that display connected locations and allow players to navigate between areas.
  
---
## ⚠️ Potential Challenges  
  
**What do you think will be the hardest part this week?**   
→   This week the most difficult portion was centered around location travel. Swapping between the different locations and traveling between them. 
  
**What is your plan if you get stuck?**   
→   Research. All the research. Geeks for Geeks was my best friend this week.
  
---
  
## 📈 Level Up Goal  
  
**What skill are you focusing on improving this week?**   
→   Vectors
  
**What will you do to improve it?**   
(e.g., tutorial, practice, debugging, office hours)   
→   Well, a lot of trial and error, but then I spent a good bit of time researching in Geeks for Geeks as well.
  
---
## 🗓️ Task Breakdown (GitHub Issues Planning)  
  
List the tasks you plan to create as GitHub Issues:  
  
- [System Features - Location.h/Location.cpp/LocationCatalog.h/LocationCatalog.cpp ]   
- [Bug - Location Catalog Not Allowing User to swap to appropriate locations.]   
- [System Features - Story/Progression State ]   
- [System Features - Core Game Loop ]   
  
---
  
## 🔥 Final Check  
  
Before you start coding, ask yourself:  
  
- [Yes ] Do I know what I’m building this week?   
- [ Yes] Do I know where to start?   
- [Yes ] Did I break my work into small tasks?   
  
If yes → start coding 🚀   
If no → refine your plan first   
  
---
## 😈 Final Thought  
  
> Plan it now… or debug it later.
Well, I spent a bit of time in both, planning and debugging. That said, I do have to say I need to work on getting into this document earlier in the week on week 3. To be
honest, I got really excited about how much I built in week 1 that the beginning of week 2 I just jumped right into coding. Most of what I jumped into coding for week 2 had
already been planned in week 1. 